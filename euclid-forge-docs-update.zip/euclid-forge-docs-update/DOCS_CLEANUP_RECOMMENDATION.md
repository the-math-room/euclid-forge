# Docs Cleanup Recommendation

## Keep and update now

Keep these because each has a distinct job:

```text
README.md
packages/core/README.md
packages/core/docs/architecture.md
packages/core/docs/denotational-model.md
packages/core/docs/public-api.md
packages/core/docs/feature-workflow.md
apps/forge/README.md
apps/forge/docs/architecture.md
apps/forge/docs/denotational-geometry-direction.md
apps/forge/docs/feature-workflow.md
docs/core-import-audit.md
```

## Consider deleting or merging later

`packages/core/docs/boundaries.md` overlaps heavily with the architecture docs and root README. It is safe to keep if it helps reviewers, but it is the strongest candidate to merge into `packages/core/docs/architecture.md` later.

`apps/forge/docs/monorepo-boundary-checklist.md` overlaps with `docs/core-import-audit.md` and the architecture docs. It is useful as a checklist, but it is also a candidate for merging into a single guardrails doc.

## Why not delete more now

This project relies on source dumps and LLM handoff. Some duplication is intentional because different review entry points need the same invariants close at hand. The better cleanup is not to eliminate every repeated sentence, but to keep repeated architectural claims synchronized.

## Current canonical wording

Use this wording wherever constrained parallel/perpendicular features are described:

```text
LINEAR_CONSTRAINED_POINT(reference, anchor, mode, offset)
SEGMENT(anchor, constrainedPoint)
```

where:

```text
mode = "PARALLEL" | "PERPENDICULAR"
```

This is dynamic construction, not a general constraint solver. Visual notation such as parallel chevrons belongs in Forge rendering, not Core graph state.
